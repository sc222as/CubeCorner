Filerna i denna katalog kan du anv�nda f�r att bygga upp ditt f�nster om du vill. 
Roligare �r ju dock om du s�tter en egen personlig touch p� applikationen med egna bilder. D� kan du radera bilderna
i denna katalog.